1.2.3 / 2020-02-07
==================

  * Fix mouse events

1.2.2 / 2020-02-07
==================

  * Fix mouse events
  * Fix repeated text on 0 length path

1.2.1 / 2018-06-22
==================

  * Update logo and turn links to https
  * Add example html page charset (utf8)

1.2.0 / 2018-03-01
==================

  * Add npm script to help releasing package versions
  * Set Leaflet as peerDependency
  * Upgrade Leaflet version from demo to `1.3.1`
  * Don't try to remove from container if container doesn't exist
  * Change way of dealing with the SVG to comply with leaflet >= 0.8
  * Remove useless console.log
